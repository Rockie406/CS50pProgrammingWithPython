print("goodbye, mon")
